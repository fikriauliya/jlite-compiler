rm *.mli *.cmo *.cmi
rm jlite_parser.ml jlite_lexer.ml as2 jlite_parser.output